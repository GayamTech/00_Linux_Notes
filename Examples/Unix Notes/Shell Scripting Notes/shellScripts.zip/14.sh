#!/bin/bash

if [ $1 -gt 100 ]
then
    echo That is a large number.
else
    echo Not even a Franklin.
fi
