#!/bin/bash

list[0]=10
list[1]=20
list[2]=30
list[3]=40
list[4]=50
list[5]=60
list[6]=70
list[7]=80
list[8]=90

for e in ${list[@]}
do
	echo $e
done
