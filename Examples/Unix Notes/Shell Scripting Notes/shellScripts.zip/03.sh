#!/bin/bash

greeting=Hello
name=Fred

echo $greeting $name!
