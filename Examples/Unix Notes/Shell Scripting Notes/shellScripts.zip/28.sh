#!/bin/bash

print_something () {
	echo Hello from function print_something
}

print_something
