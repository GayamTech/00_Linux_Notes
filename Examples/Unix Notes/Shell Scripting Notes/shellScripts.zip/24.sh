#!/bin/bash

for value in {1..9..2}
do
	echo $value
done

echo All done

# 1
# 3
# 5
# 7
# 9
# All done
