#!/bin/bash

a=$( printf "%03d" 7 )
echo $a # Prints: 007
