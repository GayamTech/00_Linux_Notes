#!/bin/bash
# My first shell script
echo hello, world
