#!/bin/bash

echo What is your name? 
read name
echo Nice to meet you $name
