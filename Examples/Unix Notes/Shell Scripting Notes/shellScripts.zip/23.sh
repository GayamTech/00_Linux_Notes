#!/bin/bash

for value in {5..1}
do
	echo $value
done

echo All done

# 5
# 4
# 3
# 2
# 1
# All done
