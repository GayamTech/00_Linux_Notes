#!/bin/bash
read -p 'Username: ' username
read -sp 'Password: ' password
echo
echo Thank you $username. We have your login credentials.
