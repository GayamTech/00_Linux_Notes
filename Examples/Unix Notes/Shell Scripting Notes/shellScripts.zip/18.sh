#!/bin/bash
southPark='Stan Kyle Cartman'
for name in $southPark
do
	echo $name
done

for name in 'Stan Kyle Cartman'
do
	echo $name
done
