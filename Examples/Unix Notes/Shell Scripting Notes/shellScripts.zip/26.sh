#!/bin/bash

while :
do
	echo "Press [CTRL+C] to break out..."
	sleep 1
done
