#!/bin/bash

a[0]=zero
a[1]=one
a[2]=two
a[4]=four
a[5]=five
a[9]=nine
echo ${#a[@]} # Prints: 6
