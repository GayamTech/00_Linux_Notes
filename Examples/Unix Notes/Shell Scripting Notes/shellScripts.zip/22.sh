#!/bin/bash

for value in {1..5}
do
	echo $value
done

echo All done

# 1
# 2
# 3
# 4
# 5
# All done
