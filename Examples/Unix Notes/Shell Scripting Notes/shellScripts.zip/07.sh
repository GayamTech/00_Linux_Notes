#!/bin/bash

count=`ls ~ | wc -l`
echo There are $count entries in your home directory
