#!/bin/bash

a=()
echo a: ${a[@]}

b=(hello world)
echo b: ${b[@]}

c[0]=Fred
echo c: ${c[@]}
